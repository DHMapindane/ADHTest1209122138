package service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

import entities.TransactionDetailsEntity;

/**
 * Session Bean implementation class EmployeeEJB
 */
@Stateless
@LocalBean
public class TransactionDetailsEJB {


	@PersistenceContext
	private EntityManager em;
	
    public TransactionDetailsEJB() {
    }
    
    public void addNewTransaction(TransactionDetailsEntity transactionDetailsEntity)
    {
    	System.out.println("============================");
    	em.persist(transactionDetailsEntity);
    	System.out.println("============================");
    }
    
    public List<TransactionDetailsEntity> DisplayTransactions()
    {
    	List<TransactionDetailsEntity> entityListData = new ArrayList<>();
    	entityListData = em.createQuery("SELECT DISTINCT t FROM Transaction_tbl t", TransactionDetailsEntity.class).getResultList();  
    	return entityListData;
    }
    

}
