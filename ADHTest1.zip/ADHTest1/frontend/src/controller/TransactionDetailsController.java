package controller;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import model.TransactionDetails;
import service.TransactionDetailsEJB;
import entities.TransactionDetailsEntity;

@ManagedBean(name = "transactionDetailsController" ,eager = true)
@SessionScoped
public class TransactionDetailsController{
 
	private String stringOutput;
    @EJB
    private TransactionDetailsEJB transactionDetailsEJB;
    
  //from form
  	@ManagedProperty(value="#{transactionDetails}")
    private TransactionDetails transactionDetails;
  	
    private List<TransactionDetails> TransactionDetailsList = new ArrayList<>();
    
   
 
    public List<TransactionDetails> getTransactions() {
	   
	    List<TransactionDetailsEntity> entityListValues = transactionDetailsEJB.DisplayTransactions();
	    TransactionDetailsList.clear();
	    for (TransactionDetailsEntity employeeEntityData : entityListValues) 
    	{
	    	System.out.println("============================");
	    	transactionDetails = new TransactionDetails();
	    	transactionDetails.setName(employeeEntityData.getName());
			transactionDetails.setSourcePassport(employeeEntityData.getSourcePassport());
			transactionDetails.setDestinationPassport(employeeEntityData.getDestinationPassport());
			transactionDetails.setDestinationBank(employeeEntityData.getDestinationBank());
			transactionDetails.setDestationCountry(employeeEntityData.getDestationCountry());
			transactionDetails.setAccountNumber(employeeEntityData.getAccountNumber());
			transactionDetails.setAmount(employeeEntityData.getAmount());
    		TransactionDetailsList.add(transactionDetails);
    	}
        return TransactionDetailsList;
    }
 
   public String viewTransactions(){
        return "TransactionDetails.xhtml";
    }
   
    public void addNewTransactions() {
    	transactionDetailsEJB.addNewTransaction(transactionDetails.getEntity());
    	stringOutput = "Record added successfully for values " + transactionDetails.getName();
    }

	public TransactionDetails getTransactionDetails() {
		return transactionDetails;
	}

	public void setTransactionDetails(TransactionDetails transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	public String getStringOutput() {
		return stringOutput;
	}

	public void setStringOutput(String stringOutput) {
		this.stringOutput = stringOutput;
	}
    
    
}