package model;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import entities.TransactionDetailsEntity;

@ManagedBean(name = "transactionDetails")
@SessionScoped
public class TransactionDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String name;
	private String sourcePassport;
	private String destinationPassport;
	private String destinationBank;
	private String destationCountry;
	private long   accountNumber;
	private double amount;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSourcePassport() {
		return sourcePassport;
	}
	public void setSourcePassport(String sourcePassport) {
		this.sourcePassport = sourcePassport;
	}
	public String getDestinationPassport() {
		return destinationPassport;
	}
	public void setDestinationPassport(String destinationPassport) {
		this.destinationPassport = destinationPassport;
	}
	public String getDestinationBank() {
		return destinationBank;
	}
	public void setDestinationBank(String destinationBank) {
		this.destinationBank = destinationBank;
	}
	public String getDestationCountry() {
		return destationCountry;
	}
	public void setDestationCountry(String destationCountry) {
		this.destationCountry = destationCountry;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public TransactionDetailsEntity getEntity()
	{
		TransactionDetailsEntity transactionDetailsEntity = new TransactionDetailsEntity();
		transactionDetailsEntity.setName(name);
		transactionDetailsEntity.setSourcePassport(sourcePassport);
		transactionDetailsEntity.setDestinationPassport(destinationPassport);
		transactionDetailsEntity.setDestinationBank(destinationBank);
		transactionDetailsEntity.setDestationCountry(destationCountry);
		transactionDetailsEntity.setAccountNumber(accountNumber);
		transactionDetailsEntity.setAmount(amount);
		return transactionDetailsEntity;
	}
	
	
	

}
